# EU-DSGVO "Recht auf Vergessenwerden" - Plugin für JTL-Shop

Dieses Plugin setzt das in der EU-Datenschutzgrundverordnung beschriebene 
Recht auf Löschung ("Recht auf Vergessenwerden") (Art. 17 - EU-DSGVO) in JTL-Shop um. 

Bei jedem Abgleich mit JTL-Wawi erledigt das Plugin dabei automatisch im Hintergrund die folgenden Bereinigungsaktionen in der JTL-Shop-Datenbank: 

* Es löscht diverse Referenzen von gelöschten Kunden in Tabellen mit personenbezogenen Daten.
* Es löscht Newsletter-Registrierungen, zu denen innerhalb von 1 Monat (Löschfrist einstellbar in den Plugin-Einstellungen) kein Opt-In erfolgte.
* Es anonymisiert personenbezogene Daten aus abgegebenen Bewertungen, eingegangenen Zahlungseingängen oder Newskommentaren, wenn der Kunden-Datensatz nicht mehr existiert. 
* Es entfernt fristgerecht Logs, die älter als 3 Monate sind (Löschfrist einstellbar in den Plugin-Einstellungen)
* Es überschreibt IP-Adressen in verschiedenen Tabellen mit "...", die vor mehr als 1 Woche in die Datenbank geschrieben wurden (Löschfrist einstellbar in den Plugin-Einstellungen). Eine Ausnahme bilden  dabei die IP-Adressen im Opt-In-Protokoll tnewsletterempfaengerhistory (hier bleiben die IP-Adressen zwecks Nachweis der Erlaubnis erhalten)
* Es löscht sämtliche veraltete Gast-Kundendaten älter als 1 Jahr (Löschfrist einstellbar in den Plugin-Einstellungen), die von JTL-Wawi abgeholt aber bisher nicht automatisch durch Wawi-Versandbestätigung oder Wawi-Stornomitteilung entfernt wurden. 

## Plugin-Kompatibilität

* JTL-Shop 3.20
* JTL-Shop 4.00 - 4.06
* In künftigen Shopversionen wird die Funktionalität nativ unterstützt, so dass dieses Plugin künftig nicht mehr zusätzlich benötigt wird. 
 

## Download

Direkt-Downloadlink der Plugin-Version 1.0: https://build.jtl-shop.de/get/jtl_gdpr_right_to_be_forgotten_v1-0-0.zip

## Plugin-Installation

Für die Installation dieses Plugins gilt die allgemeine Plugin-Installationsanleitung:  
https://guide.jtl-software.de/Plugins_f%C3%BCr_JTL-Shop_verwalten#Kurzanleitung_Plugin-Installation
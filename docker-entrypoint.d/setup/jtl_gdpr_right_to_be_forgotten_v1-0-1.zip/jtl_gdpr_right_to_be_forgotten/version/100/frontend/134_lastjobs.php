<?php 
/**
* Hook HOOK_LASTJOBS_HOLEJOBS
*
* @global JTLSmarty $smarty
* @global Plugin $oPlugin
*/

require_once __DIR__ . '/Gdpr.php';
$gdpr = new \jtl_gdpr_right_to_be_forgotten\Gdpr($oPlugin);
$gdpr->run();

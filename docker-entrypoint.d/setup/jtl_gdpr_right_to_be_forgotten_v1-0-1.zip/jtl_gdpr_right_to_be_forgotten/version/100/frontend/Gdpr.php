<?php
/**
 * @copyright (c) JTL-Software-GmbH
 * @license       http://jtl-url.de/jtlshoplicense
 */

namespace jtl_gdpr_right_to_be_forgotten;

/**
 * Class Gdpr
 * @package jtl_gdpr_right_to_be_forgotten
 */
class Gdpr
{

    /**
     * @var bool
     */
    private $isModern;

    /**
     * @var array
     */
    private $config;

    /**
     * @var \NiceDB
     */
    private $db;

    /**
     * Gdpr constructor.
     * @param \Plugin $plugin
     */
    public function __construct(\Plugin $plugin)
    {
        $this->config   = $plugin->oPluginEinstellungAssoc_arr;
        $this->isModern = version_compare(JTL_VERSION, 400, '>=');
        $this->db       = $this->isModern ? \Shop::DB() : $GLOBALS['DB'];
    }

    /**
     *
     */
    public function run()
    {
        $this->cleanupGuestAccounts();
        $this->anonymizeDeletedCustomerData();
        $this->clearCustomerRelicts();
        $this->clearNewsletterRecipients();
        $this->clearLogs();
        $this->anonymizeIPs();
        $this->removeOldGuestAccounts();
    }

    /**
     * Delete guest accounts with no open orders
     *
     * @return bool
     */
    private function cleanupGuestAccounts()
    {
        $sql = "DELETE k FROM tkunde k JOIN tbestellung b ON b.kKunde = k.kKunde WHERE b.cStatus IN (4, -1) AND k.nRegistriert = 0 AND b.cAbgeholt = 'Y';";

        return $this->db->executeQuery($sql, 3) > 0;
    }

    /**
     * Auto-anonymize personal data when customer account was deleted
     *
     * @return bool
     */
    private function anonymizeDeletedCustomerData()
    {
        $sql = "UPDATE tbewertung b 
                    SET b.cName = 'Anonym', kKunde=0 
                    WHERE b.kKunde > 0 
                        AND b.kKunde NOT IN (SELECT kKunde FROM tkunde);
                UPDATE tzahlungseingang 
                    SET cZahler = '-' 
                    WHERE cAbgeholt != 'N' 
                        AND kBestellung IN (SELECT kBestellung FROM tbestellung b WHERE b.kKunde NOT IN (SELECT kKunde FROM tkunde));
                UPDATE tnewskommentar 
                    SET cName = 'Anonym', cEmail = 'Anonym', kKunde = 0 
                    WHERE kKunde > 0 
                        AND kKunde NOT IN (SELECT kKunde FROM tkunde);";

        return $this->db->executeQuery($sql, 3) > 0;
    }

    /**
     * Delete customer relicts in logs and subtables and
     * delete shipping and billing-addresses of deleted customers
     *
     * @return bool
     */
    private function clearCustomerRelicts()
    {
        $sql = "DELETE FROM tbesucher WHERE kKunde > 0 AND kKunde NOT IN (SELECT kKunde FROM tkunde);
                DELETE FROM tbesucherarchiv WHERE kKunde > 0 AND kKunde NOT IN (SELECT kKunde FROM tkunde);
                DELETE FROM tkundenattribut WHERE kKunde NOT IN (SELECT kKunde FROM tkunde);
                DELETE FROM tkundendatenhistory WHERE kKunde NOT IN (SELECT kKunde FROM tkunde);
                DELETE FROM tkundenkontodaten WHERE kKunde > 0 AND kKunde NOT IN (SELECT kKunde FROM tkunde);
                DELETE FROM tkundenwerbenkunden WHERE kKunde > 0 AND kKunde NOT IN (SELECT kKunde FROM tkunde);
                DELETE FROM tkundenwerbenkundenbonus WHERE kKunde > 0 AND kKunde NOT IN (SELECT kKunde FROM tkunde);
                DELETE FROM tzahlungsinfo WHERE kKunde > 0 AND kKunde NOT IN (SELECT kKunde FROM tkunde);
                DELETE k 
                    FROM tlieferadresse k 
                    JOIN tbestellung b ON b.kKunde = k.kKunde 
                    WHERE b.cStatus IN (4, -1) 
                        AND b.cAbgeholt = 'Y' 
                        AND k.kKunde NOT IN (SELECT kKunde FROM tkunde);
                DELETE k 
                    FROM trechnungsadresse k 
                    JOIN tbestellung b 
                        ON b.kKunde = k.kKunde 
                        WHERE b.cStatus IN (4, -1) 
                            AND b.cAbgeholt = 'Y' 
                            AND k.kKunde NOT IN (SELECT kKunde FROM tkunde);";

        return $this->db->executeQuery($sql, 3) > 0;
    }

    /**
     * Delete newsletter-registrations with no opt-in within given interval
     * 
     * @return bool
     */
    private function clearNewsletterRecipients()
    {
        $interval = (int)$this->config['interval_clear_non_opt_newsletter_recipients'];
        if ($interval <= 0) {
            return false;
        }

        $sql = "DELETE e, h 
                  FROM tnewsletterempfaenger e 
                  JOIN tnewsletterempfaengerhistory h 
                      ON h.cOptCode = e.cOptCode AND h.cEmail = e.cEmail 
                  WHERE e.nAktiv=0 AND h.cAktion = 'Eingetragen' AND h.dOptCode = '0000-00-00' 
                      AND h.dEingetragen <= NOW() - INTERVAL " . $interval . " DAY";

        return $this->db->executeQuery($sql, 3) > 0;
    }

    /**
     * Delete old logs containing personal data
     * 
     * @return bool
     */
    private function clearLogs()
    {
        $interval = (int)$this->config['interval_clear_logs'];
        if ($interval <= 0) {
            return false;
        }

        $sql = "DELETE FROM temailhistory WHERE dSent <= NOW() - INTERVAL " . $interval . " DAY;
                DELETE FROM tjtllog WHERE (cLog LIKE '%@%' OR cLog LIKE '%kKunde%') AND dErstellt <= NOW() - INTERVAL " . $interval . " DAY;
                DELETE FROM tkundendatenhistory WHERE dErstellt <= NOW() - INTERVAL " . $interval . " DAY;
                DELETE FROM tkundenwerbenkunden WHERE dErstellt <= NOW() - INTERVAL " . $interval . " DAY;
                DELETE FROM tkontakthistory WHERE dErstellt <= NOW() - INTERVAL " . $interval . " DAY;
                DELETE FROM tzahlungseingang WHERE cAbgeholt != 'N' AND dZeit <= NOW() - INTERVAL " . $interval . " DAY;
                DELETE FROM tzahlungslog WHERE dDatum <= NOW() - INTERVAL " . $interval . " DAY;
                DELETE FROM tverfuegbarkeitsbenachrichtigung WHERE dBenachrichtigtAm <= NOW() - INTERVAL " . $interval . " DAY;
                DELETE FROM tproduktanfragehistory WHERE dErstellt <= NOW() - INTERVAL " . $interval . " DAY;";

        return $this->db->executeQuery($sql, 3) > 0;
    }

    /**
     * Anonymize IP-Adresses after x days
     * 
     * @return bool
     */
    private function anonymizeIPs()
    {
        $interval = (int)$this->config['interval_anonymize_ips'];
        if ($interval <= 0) {
            return false;
        }
        $sql = "UPDATE tbestellung SET cIP = '*.*.*.*' WHERE cIP != '*.*.*.*' AND dErstellt <= NOW() - INTERVAL " . $interval . " DAY;
                UPDATE tbesucher SET cIP = '*.*.*.*' WHERE cIP != '*.*.*.*' AND dLetzteAktivitaet <= NOW() - INTERVAL " . $interval . " DAY;
                UPDATE tbesucherarchiv SET cIP = '*.*.*.*' WHERE cIP != '*.*.*.*' AND dZeit <= NOW() - INTERVAL " . $interval . " DAY;
                UPDATE tfsession SET cIP = '*.*.*.*' WHERE cIP != '*.*.*.*' AND dErstellt <= NOW() - INTERVAL " . $interval . " DAY;
                UPDATE tkontakthistory SET cIP = '*.*.*.*' WHERE cIP != '*.*.*.*' AND dErstellt <= NOW() - INTERVAL " . $interval . " DAY;
                UPDATE tproduktanfragehistory SET cIP = '*.*.*.*' WHERE cIP != '*.*.*.*' AND dErstellt <= NOW() - INTERVAL " . $interval . " DAY;
                UPDATE tredirectreferer SET cIP = '*.*.*.*' WHERE cIP != '*.*.*.*' AND dDate <= NOW() - INTERVAL " . $interval . " DAY;
                UPDATE tsitemaptracker SET cIP = '*.*.*.*' WHERE cIP != '*.*.*.*' AND dErstellt <= NOW() - INTERVAL " . $interval . " DAY;
                UPDATE tsuchanfragencache SET cIP = '*.*.*.*' WHERE cIP != '*.*.*.*' AND dZeit <= NOW() - INTERVAL " . $interval . " DAY;
                UPDATE ttagkunde SET cIP = '*.*.*.*' WHERE cIP != '*.*.*.*' AND dZeit <= NOW() - INTERVAL " . $interval . " DAY;
                UPDATE tumfragedurchfuehrung SET cIP = '*.*.*.*' WHERE cIP != '*.*.*.*' AND dDurchgefuehrt <= NOW() - INTERVAL " . $interval . " DAY;
                UPDATE tverfuegbarkeitsbenachrichtigung SET cIP = '*.*.*.*' WHERE cIP != '*.*.*.*' AND dErstellt <= NOW() - INTERVAL " . $interval . " DAY;
                UPDATE tvergleichsliste SET cIP = '*.*.*.*' WHERE cIP != '*.*.*.*' AND dDate <= NOW() - INTERVAL " . $interval . " DAY;";

        return $this->db->executeQuery($sql, 3) > 0;
    }

    /**
     * Remove guest accounts fetched by JTL-Wawi and older than x days
     * 
     * @return bool
     */
    private function removeOldGuestAccounts()
    {
        $interval = (int)$this->config['interval_delete_guest_accounts'];
        if ($interval <= 0) {
            return false;
        }

        $sql = "DELETE FROM tkunde 
                    WHERE nRegistriert = 0 
                    AND cAbgeholt = 'Y' 
                    AND dErstellt <= NOW() - INTERVAL " . $interval . " DAY;";

        return $this->db->executeQuery($sql, 3) > 0;
    }
}

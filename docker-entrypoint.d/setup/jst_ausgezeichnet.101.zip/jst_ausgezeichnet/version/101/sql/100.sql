CREATE TABLE xplugin_jst_ausgezeichnet_snippets (
kSnippet VARCHAR (50) PRIMARY KEY ,
cSnippet text
);
# Setup

<br>

#### Workflow WAWI
Das Plugin sendet nach dem Versand einer Bestellung die TrackingID an Idealo zur&uuml;ck. Damit dies automatisch nach jedem Versand &uuml;ber die WAWI getriggert werden kann, legen Sie sich einen entsprechenden Workflow mit den folgenden Eckdaten an:

###Auftrag - Ausgeliefert

<b>Bedingung</b>
- Auftrag\Stammdaten\ExterneAuftragsnummer enth&auml;lt Idealo

<b>Aktionen</b>
- Web-Request (POST)
- URL: shopurl/IdealoIPN
- Parameter: do=updateOrder&order_number={{ Vorgang.Stammdaten.ExterneAuftragsnummer }}&internal_order_number={{ Vorgang.Stammdaten.Auftragsnummer }}

<hr>

#### Hinweis: Das Plugin erzeugt eine eigene CMS Seite mit dem SEO-Bezeichner "IdealoIPN". Bitte &auml;ndern Sie diesen bezeichner NICHT

<hr>

# Changelog

### Version 1.02 (Release 04.05.2021)

#### Neu
- Umstellung auf Idealo API v2

<hr>

### Version 1.01 (Release 14.12.2018)

#### Neu
- Versand einer Statusmail wenn Bestellungen aufgrund von nicht im Shop existierenden Artikeln NICHT abegrufen werden konnten.

<hr>

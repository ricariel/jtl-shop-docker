# Changelog

## 2.1.1
* Hotfix: Versandpreis wird mit Komma statt Punkt exportiert (SHOP-6250)

## 2.1.0
* Unterstützung für asynchronen Export im Shopbackend
* Sind Versandkosten auf Nettoberechnung eingestellt, werden die Versandkoste jetzt mit USt exportiert 
* Versandgewicht wird mit Einheit exportiert
* Funktionsattribute mit Wert=0 werden jetzt korrekt exportiert
* Vorbestellbare Produkte werden nun mit dem Wert "preorder" für den Parameter "availablility" exportiert
* Für die Standardwährung wird an exportierte Links nun kein Währungsparameter mehr angehängt
* Umlaute werden nun nicht mehr in HTML-Entities umgewandelt
* Die Formatierung für "shipping_weight" wurde korrigiert
* "Stück" wird nun als Einheit an Google Shopping weitergegeben
* Die Gewichtseinheit wird jetzt zusätzlich zum Gewicht bei "shipping_weight" exportiert

## 2.0.1
* Erlaubt leere statische Eingabewerte
* Neue Option: HTML-Tags in Produktbeschreibungen nicht mehr entfernen
* korrekte Behandlung von GTIN
* Behebt Fehler bei Ersetzen von Zeilenumbrüchen
* diverse Codeoptimierungen

## 2.0.0
* Shop5-Kompatibilität
